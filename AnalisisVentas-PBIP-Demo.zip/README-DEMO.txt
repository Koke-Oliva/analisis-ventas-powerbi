ANALISIS DE VENTAS Y COBRANZAS - DEMO REPRODUCIBLE

Este paquete usa datos sintéticos generados localmente en Power Query.
No contiene ni redistribuye los archivos académicos originales.

1. Abra AnalisisVentas.pbip con Power BI Desktop.
2. Si Power BI solicita aplicar cambios o actualizar el modelo, acepte.
3. Las tres páginas, medidas, relaciones, filtros y visualizaciones pueden revisarse e interactuarse sin archivos externos.

IMPORTANTE:
- Los valores numéricos de esta demo no deben compararse con las capturas del README.
- La estructura analítica y el diseño del informe corresponden al proyecto de portafolio.
- Los datos originales del curso no se incluyen.
